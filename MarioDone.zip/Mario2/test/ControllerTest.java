import static org.junit.jupiter.api.Assertions.*;

class ControllerTest {

    @org.junit.jupiter.api.Test
    void commitOrderToDB() {

        Controller controller = new Controller();
        controller.initMenu();
        Order order = new Order();
        order.setPhone(213452);
        order.addPizza(controller.getPizzaById(5));
        controller.commitOrderToDB(order);
    }
}
import java.sql.*;

    public class Menu {

        public void showMenu(){

            Controller controller = new Controller();
            JDBConnector jdbConnector = new JDBConnector();

            try {
                Statement statement = jdbConnector.getConnection().createStatement();
                String sql = "select * from MarioPizza.pizza";
                ResultSet rs = statement.executeQuery(sql);

                while (rs.next()) {
                    System.out.print("nr: ");
                    System.out.print(rs.getString("pizzaID"));
                    System.out.print("  ");
                    System.out.print(rs.getString("pizzaName"));
                    System.out.print(": ");
                    System.out.print(rs.getString("ingredients"));
                    System.out.print("  Pris: ");
                    System.out.print(rs.getString("price"));
                    System.out.println('\n');
                }


            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


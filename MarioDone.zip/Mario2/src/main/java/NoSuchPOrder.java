class NoSuchOrderException extends Exception{
    public NoSuchOrderException(String msg) {
        super(msg);
    }
}